const express = require('express');
const router = express.Router();
const ToolsCommunityController = require('../controllers/toolsCommunityController');

// 🔹 Ambil list chat user
// GET /api/tools/chatcommunity/chatList?key=API_KEY
router.get('/chatList', ToolsCommunityController.chatList);

// 🔹 Ambil chat history dengan user tertentu
// GET /api/tools/chatcommunity/getMessages?key=API_KEY&with=targetUsername
router.get('/getMessages', ToolsCommunityController.getMessages);

// 🔹 Kirim pesan ke user atau community
// POST /api/tools/chatcommunity/sendMessage?key=API_KEY&to=targetUsername&message=Hello
router.post('/sendMessage', ToolsCommunityController.sendMessage);

module.exports = router;