const express = require('express');
const fs = require('fs');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const { logger } = require('../utils/logger');
const { activeKeys } = require('../middleware/authMiddleware');

const CHAT_DIR = path.join(__dirname, '../data/chatCommunity');

if (!fs.existsSync(CHAT_DIR)) fs.mkdirSync(CHAT_DIR, { recursive: true });

class ToolsCommunityController {

  // Validasi key
  static validateKey(key) {
    const keyInfo = activeKeys[key];
    if (!keyInfo) return { valid: false, message: "Invalid key." };
    return { valid: true, keyInfo };
  }

  // Direktori user
  static getUserDir(username) {
    const userDir = path.join(CHAT_DIR, username);
    if (!fs.existsSync(userDir)) fs.mkdirSync(userDir, { recursive: true });
    return userDir;
  }

  // Simpan pesan
  static saveMessage(from, to, message) {
    try {
      const userDir = ToolsCommunityController.getUserDir(from);
      const sessionFile = path.join(userDir, `${to}.json`); // setiap user target punya file sendiri

      let chatHistory = [];
      if (fs.existsSync(sessionFile)) chatHistory = JSON.parse(fs.readFileSync(sessionFile, 'utf-8'));

      chatHistory.push({
        from,
        to,
        message,
        timestamp: new Date().toISOString()
      });

      fs.writeFileSync(sessionFile, JSON.stringify(chatHistory, null, 2));
      return true;
    } catch (err) {
      logger.error(`Error saving message: ${err.message}`);
      return false;
    }
  }

  // Ambil chat history user -> target
  static getChatHistory(user, target) {
    try {
      const userDir = ToolsCommunityController.getUserDir(user);
      const sessionFile = path.join(userDir, `${target}.json`);
      if (!fs.existsSync(sessionFile)) return [];
      return JSON.parse(fs.readFileSync(sessionFile, 'utf-8'));
    } catch (err) {
      logger.error(`Error reading chat history: ${err.message}`);
      return [];
    }
  }

  // Ambil list chat user
  static getChatList(user) {
    try {
      const userDir = ToolsCommunityController.getUserDir(user);
      const files = fs.readdirSync(userDir).filter(f => f.endsWith('.json'));
      return files.map(f => f.replace('.json', ''));
    } catch (err) {
      logger.error(`Error getting chat list: ${err.message}`);
      return [];
    }
  }

  // API: Get chat list
  static async chatList(req, res) {
    const { key } = req.query;
    const validation = ToolsCommunityController.validateKey(key);
    if (!validation.valid) return res.json({ valid: false, error: true, message: validation.message });

    const username = validation.keyInfo.username;
    const users = ToolsCommunityController.getChatList(username);

    return res.json({ valid: true, users });
  }

  // API: Get messages with a user
  static async getMessages(req, res) {
    const { key, with: targetUser } = req.query;
    const validation = ToolsCommunityController.validateKey(key);
    if (!validation.valid) return res.json({ valid: false, error: true, message: validation.message });
    if (!targetUser) return res.json({ valid: false, error: true, message: "Target user required" });

    const username = validation.keyInfo.username;
    const messages = ToolsCommunityController.getChatHistory(username, targetUser);

    return res.json({ valid: true, messages });
  }

  // API: Send message to user / community
  static async sendMessage(req, res) {
    const { key, to, message } = req.query;
    const validation = ToolsCommunityController.validateKey(key);
    if (!validation.valid) return res.json({ valid: false, error: true, message: validation.message });
    if (!to || !message) return res.json({ valid: false, error: true, message: "Target and message required" });

    const username = validation.keyInfo.username;
    ToolsCommunityController.saveMessage(username, to, message);

    // Simulasi balasan "community" (opsional)
    if (to === 'community') {
      ToolsCommunityController.saveMessage('CommunityBot', username, `Echo: ${message}`);
    }

    return res.json({ valid: true, message: "Message sent" });
  }
}

module.exports = ToolsCommunityController;