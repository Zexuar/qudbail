module.exports = {
  TOKEN: process.env.TELEGRAM_TOKEN || "8451224249:AAGeDHVUDn91T5ayrz9hDyvjNw_eEmHa3Xg",
  OWNER_ID: process.env.OWNER_ID || 7816220387,
  ALLOWED_GROUPS: [
    -1002351923735
  ],
  ID_GROUP_UTAMA: [
    -1002351923735
  ]
};