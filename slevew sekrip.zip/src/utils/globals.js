// Global cooldown storage
const spamCooldown = {};

module.exports = {
  spamCooldown
};