const TelegramBot = require("node-telegram-bot-api");
const { logger } = require('../utils/logger');
const { TOKEN, OWNER_ID, ALLOWED_GROUPS } = require('../config/telegram'); 
// ALLOWED_GROUPS = array of allowed group IDs, contoh: [-1001234567890, -1009876543210]

const { loadDatabase, saveDatabase } = require('./databaseService');

const bot = new TelegramBot(TOKEN, { polling: true });

// Fungsi helper untuk cek akses
function hasAccess(chatId) {
  // Bisa akses kalau private chat atau grup yang diijinkan
  return chatId > 0 || ALLOWED_GROUPS.includes(chatId);
}

// Command /start atau /menu
bot.onText(/^\/?(start|menu)/, (msg) => {
  const chatId = msg.chat.id;
  const isOwner = msg.from.id === OWNER_ID;

  if (!hasAccess(chatId)) {
    return bot.sendMessage(chatId, "❌ Maaf, grup/privatemu tidak diijinkan.");
  }

  const options = {
    reply_markup: {
      inline_keyboard: [
        [{ text: "🆕 Bikin acc member", callback_data: "create_member" }],
        [{ text: "⏳ Set Exp", callback_data: "set_expire" }],
        ...(isOwner ? [[
          { text: "📋 List Acc", callback_data: "list_user" },
          { text: "🎛 Buat Custom User", callback_data: "create_custom" },
          { text: "🗑 Hapus User", callback_data: "delete_user" }
        ]] : [])
      ]
    }
  };

  bot.sendMessage(chatId, `👋 Halo ${msg.from.first_name}, pilih menu:`, options);
});

// Callback query
bot.on("callback_query", async (query) => {
  const chatId = query.message.chat.id;
  const userId = query.from.id;
  const data = query.data;
  const isOwner = userId === OWNER_ID;

  if (!hasAccess(chatId)) {
    return bot.answerCallbackQuery(query.id, { text: "❌ Grup tidak diizinkan." });
  }

  switch (data) {
    case "create_member":
      bot.sendMessage(chatId, "Masukkan data: `username|password|durasi_hari`", { parse_mode: "Markdown" });
      bot.once("message", msg => {
        const [username, password, day] = msg.text.split("|");
        const db = loadDatabase();
        if (db.find(u => u.username === username)) return bot.sendMessage(chatId, "❌ Username sudah ada.");
        const expired = new Date();
        expired.setDate(expired.getDate() + parseInt(day));
        db.push({ username, password, role: "member", expiredDate: expired.toISOString().split("T")[0] });
        saveDatabase(db);
        bot.sendMessage(chatId, `✅ Akun member dibuat:
👤 Username: ${username}
🔐 Password: ${password}`);
      });
      break;

    case "set_expire":
      bot.sendMessage(chatId, "Masukkan: `username|tambah_hari`", { parse_mode: "Markdown" });
      bot.once("message", msg => {
        const [username, addDays] = msg.text.split("|");
        const db = loadDatabase();
        const user = db.find(u => u.username === username);
        if (!user) return bot.sendMessage(chatId, "❌ User tidak ditemukan.");

        const current = new Date(user.expiredDate);
        current.setDate(current.getDate() + parseInt(addDays));
        user.expiredDate = current.toISOString().split("T")[0];
        saveDatabase(db);
        bot.sendMessage(chatId, `✅ Masa aktif diperbarui untuk ${username} ke ${user.expiredDate}`);
      });
      break;

    case "list_user":
      if (!isOwner) return;
      const users = getFormattedUsers();
      bot.sendMessage(chatId, `📋 *Daftar Pengguna:*\n${users}`, { parse_mode: "Markdown" });
      break;

    case "create_custom":
      if (!isOwner) return;
      bot.sendMessage(chatId, "Masukkan: `username|password|role|durasi_hari`", { parse_mode: "Markdown" });
      bot.once("message", msg => {
        const [username, password, role, day] = msg.text.split("|");
        const db = loadDatabase();
        if (db.find(u => u.username === username)) return bot.sendMessage(chatId, "❌ Username sudah ada!");
        const expired = new Date();
        expired.setDate(expired.getDate() + parseInt(day));
        db.push({ username, password, role, expiredDate: expired.toISOString().split("T")[0] });
        saveDatabase(db);
        bot.sendMessage(chatId, `✅ Akun ${role} dibuat:
👤 Username: ${username}`);
      });
      break;

    case "delete_user":
      if (!isOwner) return;
      bot.sendMessage(chatId, "Masukkan username yang akan dihapus:");
      bot.once("message", msg => {
        const db = loadDatabase();
        const index = db.findIndex(u => u.username === msg.text);
        if (index === -1) return bot.sendMessage(chatId, "❌ User tidak ditemukan.");
        const deleted = db.splice(index, 1)[0];
        saveDatabase(db);
        bot.sendMessage(chatId, `🗑️ User ${deleted.username} berhasil dihapus.`);
      });
      break;
  }
});

// Helper
function getFormattedUsers() {
  const db = loadDatabase();
  return db.map(u => `👤 ${u.username} | 🎯 ${u.role || 'member'} | ⏳ ${u.expiredDate}`).join("\n");
}

function startTelegramBot() {
  console.log("Telegram bot started");
}

module.exports = 
{ 
bot,
startTelegramBot
};